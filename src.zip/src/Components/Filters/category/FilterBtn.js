import React from 'react'

const FilterBtn = ({key,item,name,set,setPageNumber}) => {
    console.log(item)
  return (
    <div>
      <style jsx>
      {`
       .x:checked + label{
        background-color :#0b5ed7;
        color: white;
      }
      input[type="radio"]{
        display:none;
      }`}
    </style>
      <div className="form-check">
  <input className="form-check-input x" type="radio" name={name} id={`${name}-${key}`}/>
  <label className="btn btn-outline-primary " for={`${name}-${key}`} onClick={()=>{set(item);setPageNumber(1)}}>{item}</label>
</div>

    </div>
  )
}

export default FilterBtn
