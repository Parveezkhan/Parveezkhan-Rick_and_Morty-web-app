import React from 'react'
import FilterBtn from './FilterBtn'

const Gender = ({setGender,setPageNumber}) => {
    let status=['female', 'male', 'genderless' , 'unknown'];
  return (
    <div>
      <div className="accordion-item">
    <h2 className="accordion-header" id="flush-headingOne">
      <button className="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
        Gender
      </button>
    </h2>
    <div id="flush-collapseOne" className="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
      <div className="accordion-body d-flex flex-wrap gap-3">
      {status.map((item,key)=>(
           <FilterBtn item={item} index={key} name='gender' set={setGender} setPageNumber={setPageNumber}/>
        ))}
      </div>
    </div>
  </div>
    </div>
  )
}

export default Gender
