import React from 'react'
import styles from "./search.module.scss";

const Search = ({setSearch,search,setPageNumber}) => {
    let val;
    let change=(e)=>{
        e.preventDefault();
       val=e.target.value;
    }
  return <form className='d-flex flex-sm-row flex-column align-items-center justify-content-center gap-4 mb-4'  onSubmit={(e)=>{
    e.preventDefault();
    setPageNumber(1);
    setSearch(val);
}}>
    <input placeholder='Search for Characters' type='text' className={styles.input} name='name' onChange={change}/>
    <button type='submit' className={`${styles.btn} btn btn-primary fs-5`} >search</button>
  </form>
  
}

export default Search
