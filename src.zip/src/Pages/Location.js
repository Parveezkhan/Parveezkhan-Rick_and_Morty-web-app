import InputGroup from '../Components/Filters/category/InputGroup'
import { useState,useEffect } from 'react';
import Cards from '../Components/Cards/Cards';

const Location = () => {
  let[id,setid]=useState(1);
  let [info,setInfo]=useState([]);
  let {name,type,dimension}=info;
  let [results,setResults]=useState([]);
  let api=`https://rickandmortyapi.com/api/location/${id}`

  useEffect(()=>{
     (async function(){
      let data=await fetch(api).then(res=>res.json())
      setInfo(data);

      let a =await Promise.all(
        data.residents.map((x) =>{
          return fetch(x).then((res) => res.json());
        })
      );
      setResults(a);
     })()
  },[api])
 console.log(info)
 console.log(results)
  return (
    <div className='container'>
      <div className='row mb-3'>
        <h1 className='text-center mb-3'>Location :{" "} <span className='text-primary'>{name===" "?"unknown":name}</span></h1>
        <h5 className='text-center'>Dimension : {dimension===" "?"unknown":dimension}</h5>
        <h5 className='text-center'>Type : {type===" "?"unknown":type} </h5>
      </div>
      <div className='row'>
        <div className='col-lg-3 col-12'>
          <h4 className='text-center mb-4'>
          Pick Locations
          </h4>
         <InputGroup total={126} setid={setid} name='location'/>
        </div>
        <div className='col-lg-8 col-12'>
          <div className='row'><Cards  page='/Location/' results={results}/></div>
        </div>
      </div>
    </div>
  )
}

export default Location
